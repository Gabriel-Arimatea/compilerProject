int variavel;
string test;

int main(){
	/*erro léxico na string abaixo*/
	test = "uma string   
	qualquer";
	/*erro sintático a seguir, mas nenhum erro léxico*/
	variavel
	/*e só pra /*constar*/ comentários assim são válidos.
	A falta do return também não é um erro léxico*/
}
