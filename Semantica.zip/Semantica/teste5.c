int a;
a = 5;
string b = "bla";

void main(){
	/*vou fazer um exemplo lexicamente correto, com if e while só pra constar*/
	if(b >= 2){
		fat(b);
	}else{
		printf("%d", b);
	}
	while(a > 1){
		a = a - 1;
	}
	return;
}
/*À medida que eu for vendo os erros nos programas de vocês eu vou criando novos testes*/