/*erro l�xico no identificador abaixo*/
int teste;
string var;

int main(){
	var = "blabla blablabla \n";
	teste = 1+2;
	printf("bla %s", var);
	return 0;
}
